package id.sulistiyanto.pendaftaranpraktikum;

/**
 * Created by sulistiyanto on 07/12/16.
 */

public class Result {

    String npm;
    String nama;
    String kelas;
    String sesi;

    public String getNpm() {
        return npm;
    }

    public String getNama() {
        return nama;
    }

    public String getKelas() {
        return kelas;
    }

    public String getSesi() {
        return sesi;
    }
}
