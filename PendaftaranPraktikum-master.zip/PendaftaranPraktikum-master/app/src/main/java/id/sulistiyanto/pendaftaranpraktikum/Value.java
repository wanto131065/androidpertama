package id.sulistiyanto.pendaftaranpraktikum;

import java.util.List;

/**
 * Created by sulistiyanto on 07/12/16.
 */

public class Value {

    String value;
    String message;
    List<Result> result;

    public String getValue() {
        return value;
    }

    public String getMessage() {
        return message;
    }

    public List<Result> getResult() {
        return result;
    }
}
